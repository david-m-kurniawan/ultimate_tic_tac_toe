package Default;

public enum Winner {
    NONE(""),
    X("-fx-color: midnightblue;-fx-border-color: darkgoldenrod; -fx-border-width: 2; -fx-border-radius: 2"),
    O("-fx-color: maroon;-fx-border-color: darkgreen; -fx-border-width: 2; -fx-border-radius: 2"),
    TIE("-fx-color: silver;-fx-border-color: black; -fx-border-width: 2; -fx-border-radius: 2");

    private final String style;

    Winner(String style) {
        this.style = style;
    }

    public String getStyle() {
        return style;
    }
}
