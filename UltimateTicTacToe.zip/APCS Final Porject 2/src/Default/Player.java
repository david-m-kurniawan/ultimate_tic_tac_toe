package Default;

public enum Player {
    X("-fx-text-fill: midnightblue;"),
    O("-fx-text-fill: maroon;");

    private final String style;

    Player(String style) {
        this.style = style;
    }

    public String getStyle() {
        return style;
    }
}
